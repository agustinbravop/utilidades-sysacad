# Michiutilidades SYSACAD FFRe

Extensión de Chrome con un conjunto de utilidades que extienden al SYSACAD de la UTN FRRe para ofrecer más información y comodidades al alumno. Iniciativa de alumnos independiente a la institución.

El objetivo de Michiutilidades es simplemente mejorar la manera en la que la información del SYSACAD es mostrada, sin cambiar radicalmente el diseño original.

## Funcionalidades

- Personalizar la imagen de fondo.
- Mostrar promedios en el listado de exámenes finales.

## Feedback

Si encontraste algún error no dudes en crear un GitHub Issue para reportarlo. También nos podes dejar sugerencias para mejorar la extensión o agregar funcionalidades nuevas.
